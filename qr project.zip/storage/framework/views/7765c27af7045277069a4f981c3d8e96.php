<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <style>

        .container {
    display: flex;
    flex-wrap: wrap; 
    justify-content: center; 
    width: 80%;
    margin-top: 30px;
    margin-left: auto; /* Center the container horizontally */
    margin-right: auto; /* Center the container horizontally */
}


        .button {

            background-color: transparent;
            border: 1px solid #000000;
            color: black;
            border-radius: 5px;
            padding: 50px 30px;
            font-size: 24px;
            margin: 10px;
            flex: 1 1 calc(25% - 40px);
            transition: background-color 0.3s;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            text-align: center;
        }

        .button i {
            font-size: 32px; /* Increased icon size */
            margin-bottom: 10px; /* Increased margin for better spacing */
        }

        .button:hover {
            background-color: #d3d3d38f; 
            color: black;
            text-decoration: none; 
            transition: background-color 0.5s;

            /* border: 1px solid black; */
        }

        @media (max-width: 768px) {
            .button {
                flex: 1 1 calc(50% - 20px); /* Adjust to fit 2 buttons in a row */
            }
        }

        @media (max-width: 480px) {
            .button {
                flex: 1 1 calc(100% - 20px); /* Stack buttons on small screens */
            }
        }
    </style>

    <div class="container">
        <?php if(auth()->user()->status == 1): ?>
            <a href="<?php echo e(url('properties')); ?>" class="button">
                <i class="fas fa-building"></i>
                <span>Properties</span>
                <span><?php echo e($total_properties); ?></span>
            </a>

            <a href="<?php echo e(url('resident')); ?>" class="button">
                <i class="fas fa-users"></i>
                <span>Residents</span>
                <span><?php echo e(auth()->user()->resident->count()); ?></span>
            </a>
        <?php endif; ?>

        <a href="<?php echo e(url('visitors')); ?>" class="button">
            <i class="fas fa-user-friends"></i>
            <span>Visitors</span>
            <span><?php echo e($total_visitor); ?></span>
        </a>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\QR-CODE-BARRIER-master\resources\views/dashboard.blade.php ENDPATH**/ ?>