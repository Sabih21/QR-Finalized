
<?php /**PATH C:\xampp\htdocs\QR-CODE-BARRIER-master\resources\views/components/application-logo.blade.php ENDPATH**/ ?>