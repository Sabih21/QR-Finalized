
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container">
<div class="card mt-5">
  <h2 class="card-header">Visitor Access</h2>
  <div class="card-body">
          
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="alert alert-success" role="alert"> <?php echo e($value); ?> </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
  
        <div class="d-grid gap-2 d-md-flex justify-content-md-end flex-wrap flex-column align-items-end">
            
            <?php if($visitor->status == 2): ?>
                <a class="btn btn-success btn-sm" href="<?php echo e(route('vaccess.create', ['id' => $_GET['id']])); ?>" > <i class="fa fa-plus"></i> Add New Visitor Access</a>
            <?php else: ?>
                
                <button class="btn btn-success btn-sm btn-disabled" disabled> <i class="fa fa-plus"></i> Add New Visitor Access</button>
                <small class="text-muted" style="font-size:10px">This user has valid active access, try deactivating in order to create a new access (QR) </small>
            <?php endif; ?>
        </div>
  
        <table class="table table-bordered table-striped mt-4">
            <thead>
                <tr>
                    <th width="80px">No</th>
                    
                    <th>Start time</th>
                    <th>End time</th>
                    <th>Status</th>
                    <th width="250px">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vaccess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th> <?php echo e($access->id); ?> </th>
                    <th> <?php echo e($access->start_time); ?> </th>
                    <th> <?php echo e($access->end_time); ?></th>
                    <th> <?php echo $access->access; ?> </th>
                    <th>
                        <form action="<?php echo e(route('vaccess.destroy',$access->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                                
                        <?php if($access->status == 1): ?>
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-link-slash"></i> Deactivate?</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-danger btn-sm" disabled>Deactivated</button>
                        <?php endif; ?>
                        
                            </form>    
                    </th>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        
      
  
  </div>
</div>  

</div>
    

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\QR-CODE-BARRIER-master\resources\views/vaccess/index.blade.php ENDPATH**/ ?>